"""Thin async wrapper over the Moodle Web Services REST API."""

from __future__ import annotations

import os
from typing import Any

import httpx


class MoodleError(RuntimeError):
    """Raised when Moodle returns an exception payload."""


class MoodleClient:
    def __init__(
        self,
        base_url: str | None = None,
        token: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        base_url = (base_url or os.environ.get("MOODLE_URL", "")).rstrip("/")
        token = token or os.environ.get("MOODLE_TOKEN", "")
        if not base_url:
            raise RuntimeError("MOODLE_URL is not set")
        if not token:
            raise RuntimeError("MOODLE_TOKEN is not set")
        self.base_url = base_url
        self.token = token
        self.endpoint = f"{base_url}/webservice/rest/server.php"
        self._client = httpx.AsyncClient(timeout=timeout)

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def _flatten(data: Any, prefix: str = "") -> dict[str, Any]:
        """Moodle expects PHP-style bracket notation for nested params."""
        out: dict[str, Any] = {}
        if isinstance(data, dict):
            for key, value in data.items():
                if value is None:
                    continue
                new_prefix = f"{prefix}[{key}]" if prefix else str(key)
                out.update(MoodleClient._flatten(value, new_prefix))
        elif isinstance(data, (list, tuple)):
            for idx, value in enumerate(data):
                out.update(MoodleClient._flatten(value, f"{prefix}[{idx}]"))
        else:
            if isinstance(data, bool):
                data = 1 if data else 0
            out[prefix] = data
        return out

    async def call(self, wsfunction: str, **params: Any) -> Any:
        payload = {
            "wstoken": self.token,
            "wsfunction": wsfunction,
            "moodlewsrestformat": "json",
        }
        payload.update(self._flatten({k: v for k, v in params.items() if v is not None}))

        resp = await self._client.post(self.endpoint, data=payload)
        resp.raise_for_status()

        try:
            data = resp.json()
        except ValueError as exc:  # pragma: no cover - Moodle misconfiguration
            raise MoodleError(f"Non-JSON response from Moodle: {resp.text[:400]}") from exc

        if isinstance(data, dict) and data.get("exception"):
            raise MoodleError(
                f"{data.get('errorcode', 'error')}: {data.get('message', 'unknown Moodle error')}"
            )
        if isinstance(data, dict) and data.get("warnings"):
            # keep warnings but do not fail
            pass
        return data

    async def aclose(self) -> None:
        await self._client.aclose()


_client: MoodleClient | None = None


def get_client() -> MoodleClient:
    global _client
    if _client is None:
        _client = MoodleClient()
    return _client
