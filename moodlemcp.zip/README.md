# moodle-mcp

An MCP server that exposes a Moodle LMS over **Streamable HTTP**, ready to deploy on Render as a service named `moodle-mcp`.

Once deployed your endpoint is:

```
https://moodle-mcp.onrender.com/mcp
```

(Render appends a random suffix if that name is taken — use the exact URL shown on the service page.)

---

## 1. Get a Moodle web service token

In Moodle, as an admin:

1. **Site administration → Advanced features** → enable `Enable web services`.
2. **Site administration → Server → Web services → Manage protocols** → enable **REST protocol**.
3. **Site administration → Server → Web services → External services** → add a service (e.g. "MCP"), tick *Enabled* and *Authorised users only*.
4. **Add functions** to that service. Minimum set for all tools here:

```
core_webservice_get_site_info
core_course_get_courses
core_course_get_courses_by_field
core_course_search_courses
core_course_get_contents
core_course_get_categories
core_enrol_get_users_courses
core_enrol_get_enrolled_users
core_user_get_users
core_group_get_course_groups
core_group_get_group_members
mod_assign_get_assignments
mod_assign_get_submissions
mod_assign_get_grades
gradereport_user_get_grade_items
gradereport_user_get_grades_table
mod_quiz_get_quizzes_by_courses
mod_quiz_get_user_attempts
mod_quiz_get_user_best_grade
mod_forum_get_forums_by_courses
mod_forum_get_forum_discussions
mod_forum_get_discussion_posts
core_calendar_get_calendar_events
core_calendar_get_action_events_by_timesort
```

Add `enrol_manual_enrol_users` and `enrol_manual_unenrol_users` only if you want the write tools.

5. **Manage tokens → Create token** for a service account user. Copy the token.

---

## 2. Deploy on Render

### Option A — Blueprint (uses `render.yaml`, keeps the name `moodle-mcp`)

1. Push this folder to a GitHub/GitLab repo.
2. Render Dashboard → **New +** → **Blueprint** → pick the repo.
3. Render reads `render.yaml` and proposes a web service named **moodle-mcp**. Apply.
4. When prompted, fill in `MOODLE_URL` and `MOODLE_TOKEN`. `MCP_API_KEY` is generated for you.
5. After the first deploy, open **Environment** and copy the generated `MCP_API_KEY` — clients need it.

### Option B — Manual web service

1. Render Dashboard → **New +** → **Web Service** → connect the repo.
2. **Name:** `moodle-mcp`
3. **Language:** Python 3 · **Branch:** main
4. **Build Command:** `pip install -r requirements.txt`
5. **Start Command:** `python server.py`
6. **Health Check Path:** `/healthz`
7. **Environment variables:**

| Key | Value |
|---|---|
| `MOODLE_URL` | `https://your-moodle-site` (no trailing slash) |
| `MOODLE_TOKEN` | your Moodle web service token |
| `MCP_API_KEY` | a long random string you generate |
| `MOODLE_ALLOW_WRITES` | `false` |
| `PYTHON_VERSION` | `3.11.9` |

8. Create Web Service.

> On Render's **free** plan the service sleeps after 15 minutes idle, so the first MCP call after a nap takes ~30–60s. The Starter plan stays warm.

---

## 3. Verify

```bash
curl https://moodle-mcp.onrender.com/healthz
# {"status":"ok","service":"moodle-mcp","transport":"streamable-http","endpoint":"/mcp",...}

curl -X POST https://moodle-mcp.onrender.com/mcp \
  -H "Authorization: Bearer $MCP_API_KEY" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

---

## 4. Connect a client

**Claude (custom connector) / Cowork:** add a remote MCP server

- URL: `https://moodle-mcp.onrender.com/mcp`
- Header: `Authorization: Bearer <MCP_API_KEY>`

**`claude mcp add` (CLI):**

```bash
claude mcp add --transport http moodle https://moodle-mcp.onrender.com/mcp \
  --header "Authorization: Bearer <MCP_API_KEY>"
```

**Generic JSON config:**

```json
{
  "mcpServers": {
    "moodle": {
      "type": "http",
      "url": "https://moodle-mcp.onrender.com/mcp",
      "headers": { "Authorization": "Bearer <MCP_API_KEY>" }
    }
  }
}
```

---

## Tools (25, plus 2 write tools when enabled)

**Site** — `moodle_site_info`

**Courses & content** — `list_courses`, `search_courses`, `get_courses_by_field`, `get_course_contents`, `list_categories`, `my_courses`

**Users & enrolments** — `search_users`, `get_enrolled_users`, `get_course_groups`, `get_group_members`, *(`enrol_user`, `unenrol_user` when `MOODLE_ALLOW_WRITES=true`)*

**Assignments & grades** — `list_assignments`, `get_assignment_submissions`, `get_assignment_grades`, `get_gradebook`, `get_grades_table`

**Quizzes, forums, calendar** — `list_quizzes`, `get_quiz_attempts`, `get_quiz_best_grade`, `list_forums`, `get_forum_discussions`, `get_discussion_posts`, `get_calendar_events`, `get_upcoming_deadlines`

**Escape hatch** — `call_moodle_function` (any WS function the token allows)

---

## Local run

```bash
pip install -r requirements.txt
cp .env.example .env   # fill it in
set -a && source .env && set +a
python server.py
```

## Security notes

- The Moodle token inherits the permissions of the Moodle user it was issued to. Issue it to a least-privilege service account, not an admin, unless you need admin-level reads.
- `MCP_API_KEY` is the only thing standing between the internet and your Moodle data. Keep it long and rotate it if leaked.
- Writes are off by default.
