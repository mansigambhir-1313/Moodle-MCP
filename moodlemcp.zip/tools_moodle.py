"""MCP tool definitions for Moodle Web Services."""

from __future__ import annotations

import os
from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from moodle_client import get_client

ALLOW_WRITES = os.environ.get("MOODLE_ALLOW_WRITES", "false").lower() in {"1", "true", "yes"}


def register(mcp: FastMCP) -> None:
    # ================================================================= general
    @mcp.tool()
    async def moodle_site_info() -> dict[str, Any]:
        """Return Moodle site info for the token's user: site name, version, user id,
        and the list of web service functions the token is allowed to call.
        Use this first to confirm connectivity and available permissions."""
        return await get_client().call("core_webservice_get_site_info")

    # ====================================================== courses & content
    @mcp.tool()
    async def list_courses(
        ids: Annotated[list[int] | None, Field(description="Optional course ids to filter by")] = None,
    ) -> Any:
        """List courses on the site (optionally only the given course ids)."""
        params: dict[str, Any] = {}
        if ids:
            params["options"] = {"ids": ids}
        return await get_client().call("core_course_get_courses", **params)

    @mcp.tool()
    async def search_courses(
        query: Annotated[str, Field(description="Free-text search term")],
        page: Annotated[int, Field(description="Zero-based page number")] = 0,
        per_page: Annotated[int, Field(description="Results per page", le=100)] = 20,
    ) -> Any:
        """Search the course catalogue by free text."""
        return await get_client().call(
            "core_course_search_courses",
            criterianame="search",
            criteriavalue=query,
            page=page,
            perpage=per_page,
        )

    @mcp.tool()
    async def get_courses_by_field(
        field: Annotated[str, Field(description="One of: id, ids, shortname, idnumber, category")],
        value: Annotated[str, Field(description="Value to match for the given field")],
    ) -> Any:
        """Fetch course(s) by a specific field such as shortname or category."""
        return await get_client().call("core_course_get_courses_by_field", field=field, value=value)

    @mcp.tool()
    async def get_course_contents(
        course_id: Annotated[int, Field(description="Moodle course id")],
    ) -> Any:
        """Get the full section/module/resource tree for a course."""
        return await get_client().call("core_course_get_contents", courseid=course_id)

    @mcp.tool()
    async def list_categories() -> Any:
        """List all course categories."""
        return await get_client().call("core_course_get_categories")

    @mcp.tool()
    async def my_courses(
        user_id: Annotated[int | None, Field(description="User id; defaults to the token's own user")] = None,
    ) -> Any:
        """List the courses a user is enrolled in."""
        if user_id is None:
            info = await get_client().call("core_webservice_get_site_info")
            user_id = info["userid"]
        return await get_client().call("core_enrol_get_users_courses", userid=user_id)

    # ==================================================== users & enrolments
    @mcp.tool()
    async def search_users(
        key: Annotated[str, Field(description="Field to search: email, username, firstname, lastname, id")],
        value: Annotated[str, Field(description="Value to match")],
    ) -> Any:
        """Find site users by a field/value pair."""
        return await get_client().call(
            "core_user_get_users", criteria=[{"key": key, "value": value}]
        )

    @mcp.tool()
    async def get_enrolled_users(
        course_id: Annotated[int, Field(description="Moodle course id")],
        limit: Annotated[int, Field(description="Max users to return (0 = all)")] = 100,
        offset: Annotated[int, Field(description="Offset for paging")] = 0,
    ) -> Any:
        """List users enrolled in a course, with their roles."""
        return await get_client().call(
            "core_enrol_get_enrolled_users",
            courseid=course_id,
            options=[
                {"name": "limitnumber", "value": limit},
                {"name": "limitfrom", "value": offset},
            ],
        )

    @mcp.tool()
    async def get_course_groups(
        course_id: Annotated[int, Field(description="Moodle course id")],
    ) -> Any:
        """List the groups defined in a course."""
        return await get_client().call("core_group_get_course_groups", courseid=course_id)

    @mcp.tool()
    async def get_group_members(
        group_ids: Annotated[list[int], Field(description="Group ids to inspect")],
    ) -> Any:
        """List the member user ids of the given groups."""
        return await get_client().call("core_group_get_group_members", groupids=group_ids)

    if ALLOW_WRITES:

        @mcp.tool()
        async def enrol_user(
            course_id: Annotated[int, Field(description="Moodle course id")],
            user_id: Annotated[int, Field(description="Moodle user id")],
            role_id: Annotated[int, Field(description="Role id: 5=student, 3=editingteacher, 4=teacher")] = 5,
        ) -> str:
            """Manually enrol a user into a course. WRITE ACTION.
            Only available when MOODLE_ALLOW_WRITES=true."""
            await get_client().call(
                "enrol_manual_enrol_users",
                enrolments=[{"roleid": role_id, "userid": user_id, "courseid": course_id}],
            )
            return f"Enrolled user {user_id} into course {course_id} with role {role_id}."

        @mcp.tool()
        async def unenrol_user(
            course_id: Annotated[int, Field(description="Moodle course id")],
            user_id: Annotated[int, Field(description="Moodle user id")],
        ) -> str:
            """Remove a user's manual enrolment from a course. WRITE ACTION.
            Only available when MOODLE_ALLOW_WRITES=true."""
            await get_client().call(
                "enrol_manual_unenrol_users",
                enrolments=[{"userid": user_id, "courseid": course_id}],
            )
            return f"Unenrolled user {user_id} from course {course_id}."

    # =================================================== assignments & grades
    @mcp.tool()
    async def list_assignments(
        course_ids: Annotated[list[int] | None, Field(description="Course ids; omit for all visible courses")] = None,
    ) -> Any:
        """List assignments (mod_assign) for the given courses, including due dates."""
        return await get_client().call("mod_assign_get_assignments", courseids=course_ids or [])

    @mcp.tool()
    async def get_assignment_submissions(
        assignment_ids: Annotated[list[int], Field(description="Assignment instance ids")],
        status: Annotated[str | None, Field(description="Filter: submitted, draft, new, reopened")] = None,
    ) -> Any:
        """Get submissions for one or more assignments."""
        return await get_client().call(
            "mod_assign_get_submissions", assignmentids=assignment_ids, status=status
        )

    @mcp.tool()
    async def get_assignment_grades(
        assignment_ids: Annotated[list[int], Field(description="Assignment instance ids")],
    ) -> Any:
        """Get grades recorded against one or more assignments."""
        return await get_client().call("mod_assign_get_grades", assignmentids=assignment_ids)

    @mcp.tool()
    async def get_gradebook(
        course_id: Annotated[int, Field(description="Moodle course id")],
        user_id: Annotated[int, Field(description="User id; 0 returns all users the caller may see")] = 0,
    ) -> Any:
        """Get gradebook items and grades for a course (optionally a single user)."""
        return await get_client().call(
            "gradereport_user_get_grade_items", courseid=course_id, userid=user_id
        )

    @mcp.tool()
    async def get_grades_table(
        course_id: Annotated[int, Field(description="Moodle course id")],
        user_id: Annotated[int, Field(description="User id; 0 for all visible users")] = 0,
    ) -> Any:
        """Get the rendered user grade report table for a course."""
        return await get_client().call(
            "gradereport_user_get_grades_table", courseid=course_id, userid=user_id
        )

    # ================================================ quizzes, forums, calendar
    @mcp.tool()
    async def list_quizzes(
        course_ids: Annotated[list[int] | None, Field(description="Course ids; omit for all")] = None,
    ) -> Any:
        """List quizzes in the given courses."""
        return await get_client().call("mod_quiz_get_quizzes_by_courses", courseids=course_ids or [])

    @mcp.tool()
    async def get_quiz_attempts(
        quiz_id: Annotated[int, Field(description="Quiz instance id")],
        user_id: Annotated[int | None, Field(description="User id; defaults to the token's user")] = None,
        status: Annotated[str, Field(description="all, finished, or unfinished")] = "all",
    ) -> Any:
        """List a user's attempts at a quiz."""
        return await get_client().call(
            "mod_quiz_get_user_attempts", quizid=quiz_id, userid=user_id, status=status
        )

    @mcp.tool()
    async def get_quiz_best_grade(
        quiz_id: Annotated[int, Field(description="Quiz instance id")],
        user_id: Annotated[int | None, Field(description="User id; defaults to the token's user")] = None,
    ) -> Any:
        """Get a user's best grade on a quiz."""
        return await get_client().call("mod_quiz_get_user_best_grade", quizid=quiz_id, userid=user_id)

    @mcp.tool()
    async def list_forums(
        course_ids: Annotated[list[int] | None, Field(description="Course ids; omit for all")] = None,
    ) -> Any:
        """List forums in the given courses."""
        return await get_client().call("mod_forum_get_forums_by_courses", courseids=course_ids or [])

    @mcp.tool()
    async def get_forum_discussions(
        forum_id: Annotated[int, Field(description="Forum instance id")],
        page: Annotated[int, Field(description="Zero-based page; -1 for all")] = 0,
        per_page: Annotated[int, Field(description="Discussions per page", le=100)] = 20,
    ) -> Any:
        """List discussion threads in a forum."""
        return await get_client().call(
            "mod_forum_get_forum_discussions", forumid=forum_id, page=page, perpage=per_page
        )

    @mcp.tool()
    async def get_discussion_posts(
        discussion_id: Annotated[int, Field(description="Forum discussion id")],
    ) -> Any:
        """Read all posts in a forum discussion thread."""
        return await get_client().call("mod_forum_get_discussion_posts", discussionid=discussion_id)

    @mcp.tool()
    async def get_calendar_events(
        course_ids: Annotated[list[int] | None, Field(description="Restrict to these course ids")] = None,
        time_start: Annotated[int | None, Field(description="Unix timestamp lower bound")] = None,
        time_end: Annotated[int | None, Field(description="Unix timestamp upper bound")] = None,
        limit: Annotated[int, Field(description="Max events", le=200)] = 50,
    ) -> Any:
        """Get calendar events (deadlines, sessions) for courses and the site."""
        options: dict[str, Any] = {"userevents": 1, "siteevents": 1, "ignorehidden": 1}
        if time_start is not None:
            options["timestart"] = time_start
        if time_end is not None:
            options["timeend"] = time_end
        return await get_client().call(
            "core_calendar_get_calendar_events",
            events={"courseids": course_ids or []},
            options=options,
        )

    @mcp.tool()
    async def get_upcoming_deadlines(
        limit: Annotated[int, Field(description="Max items", le=100)] = 25,
    ) -> Any:
        """Get the current user's upcoming action events (assignment/quiz deadlines)."""
        return await get_client().call(
            "core_calendar_get_action_events_by_timesort", limitnum=limit
        )

    # ------------------------------------------------------------ escape hatch
    @mcp.tool()
    async def call_moodle_function(
        wsfunction: Annotated[str, Field(description="Any Moodle web service function name")],
        params_json: Annotated[str, Field(description="JSON object of parameters, e.g. {\"courseid\": 2}")] = "{}",
    ) -> Any:
        """Call an arbitrary Moodle web service function the token is authorised for.
        Use only when no dedicated tool above covers the need."""
        import json

        params = json.loads(params_json)
        if not isinstance(params, dict):
            raise ValueError("params_json must be a JSON object")
        return await get_client().call(wsfunction, **params)
