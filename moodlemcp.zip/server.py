"""moodle-mcp — an MCP server exposing Moodle over Streamable HTTP.

Endpoints
  GET  /healthz  -> liveness probe (no auth)
  ANY  /mcp      -> MCP Streamable HTTP transport (bearer auth if MCP_API_KEY set)
"""

from __future__ import annotations

import os

import uvicorn
from mcp.server.fastmcp import FastMCP
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route

import tools_moodle

MCP_API_KEY = os.environ.get("MCP_API_KEY", "").strip()

mcp = FastMCP(
    name="moodle-mcp",
    instructions=(
        "Tools for a Moodle LMS: courses and content, users and enrolments, "
        "assignments and grades, quizzes, forums and calendar deadlines. "
        "Call moodle_site_info first to confirm which functions the token allows."
    ),
    stateless_http=True,
    json_response=False,
)
tools_moodle.register(mcp)


class BearerAuthMiddleware(BaseHTTPMiddleware):
    """Require `Authorization: Bearer <MCP_API_KEY>` on the MCP endpoint."""

    async def dispatch(self, request, call_next):
        if not MCP_API_KEY:
            return await call_next(request)
        if request.url.path.rstrip("/") in ("/healthz", ""):
            return await call_next(request)

        header = request.headers.get("authorization", "")
        supplied = header[7:].strip() if header.lower().startswith("bearer ") else ""
        if not supplied:
            supplied = request.headers.get("x-api-key", "").strip()

        import hmac

        if not hmac.compare_digest(supplied, MCP_API_KEY):
            return JSONResponse(
                {"error": "unauthorized", "detail": "Missing or invalid bearer token."},
                status_code=401,
                headers={"WWW-Authenticate": 'Bearer realm="moodle-mcp"'},
            )
        return await call_next(request)


async def healthz(_request):
    return JSONResponse(
        {
            "status": "ok",
            "service": "moodle-mcp",
            "transport": "streamable-http",
            "endpoint": "/mcp",
            "auth_required": bool(MCP_API_KEY),
            "moodle_configured": bool(os.environ.get("MOODLE_URL")),
        }
    )


def build_app() -> Starlette:
    session_app = mcp.streamable_http_app()
    return Starlette(
        routes=[
            Route("/healthz", healthz, methods=["GET"]),
            Route("/", healthz, methods=["GET"]),
            Mount("/", app=session_app),
        ],
        middleware=[Middleware(BearerAuthMiddleware)],
        lifespan=lambda app: session_app.router.lifespan_context(app),
    )


app = build_app()


if __name__ == "__main__":
    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "8000")),
        log_level=os.environ.get("LOG_LEVEL", "info"),
    )
